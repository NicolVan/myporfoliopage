﻿using dufeksoft.lib.Img;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResizeImages
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            tbMaxWidth.Text = "1200";
            tbMaxHeight.Text = "0";
            this.ActiveControl = tbDirectory;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            string path = tbDirectory.Text;
            if (string.IsNullOrEmpty(path))
            {
                MessageBox.Show("Nie je zadaný adresár pre úpravu obrázkov.");
                return;
            }

            int maxWidth = int.Parse(tbMaxWidth.Text);
            int maxHeight = int.Parse(tbMaxHeight.Text);
            ConvertImagesHelper convertor = new ConvertImagesHelper();

            var progress = new Progress<string>(s => label.Text = s);
            await Task.Factory.StartNew(() => convertor.ConvertImages(progress, path, maxWidth, maxHeight), TaskCreationOptions.LongRunning);
            label.Text = "";

            if (convertor.WasError)
            {
                MessageBox.Show(string.Format("Chyba pri úprave {0}.\nPozri log súbor {1}.", path, convertor.LogFile));
            }
            else
            {
                MessageBox.Show(string.Format("Úspešne upravené {0}.\nPozri log súbor {1}.", path, convertor.LogFile));
            }
        }

        private void btnSelectDirectory_Click(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    tbDirectory.Text = fbd.SelectedPath;
                }
            }
        }
    }

    class ConvertImagesHelper
    {
        public int MaxWidth { get; private set; }
        public string LogFile { get; private set; }
        public bool WasError { get; private set; }

        public void ConvertImages(IProgress<string> progress, string path, int maxWidth, int maxHeight)
        {
            this.WasError = false;
            this.LogFile = string.Format(@"{0}\convert.log", path.TrimEnd('\\'));

            ImageResizer ir = new ImageResizer();
            List<string> imgList = DirSearch(path);
            SortedList<string, string> sortedImgList = new SortedList<string, string>();
            foreach (string file in imgList)
            {
                sortedImgList.Add(file, file);
            }

            using (StreamWriter tw = new StreamWriter(this.LogFile))
            {
                string currentFile = "NONE";
                try
                {
                    int cnt = 0;
                    int maxCnt = sortedImgList.Values.Count;

                    foreach (string file in sortedImgList.Values)
                    {
                        currentFile = file;
                        progress.Report(string.Format("{0} / {1} -> {2}", ++cnt, maxCnt, currentFile));

                        if (file.ToLower().EndsWith(".jpg") || file.ToLower().EndsWith(".jpeg"))
                        {
                            ir.MakeJpgSmaller(file, maxWidth, maxHeight);
                            tw.WriteLine(string.Format("SPRACOVANÉ: {0}", file));
                        }
                        else
                        {
                            tw.WriteLine(string.Format("PRESKOČENÉ: {0}", file));
                        }
                    }
                }
                catch (Exception exc)
                {
                    tw.WriteLine("");
                    tw.WriteLine("");
                    tw.WriteLine("");
                    tw.WriteLine(string.Format("CHYBA SÚBORU: {0}", currentFile));
                    tw.WriteLine("DETAIL CHYBY:");
                    tw.WriteLine(exc.ToString());

                    this.WasError = true;
                }
            }
        }

        private List<String> DirSearch(string sDir)
        {
            List<String> files = new List<String>();
            try
            {
                foreach (string f in Directory.GetFiles(sDir))
                {
                    files.Add(f);
                }
                foreach (string d in Directory.GetDirectories(sDir))
                {
                    files.AddRange(DirSearch(d));
                }
            }
            catch (System.Exception excpt)
            {
                MessageBox.Show(excpt.Message);
            }

            return files;
        }
    }
}
