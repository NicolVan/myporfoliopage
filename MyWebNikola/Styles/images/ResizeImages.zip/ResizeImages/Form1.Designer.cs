﻿namespace ResizeImages
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.lbMaxWidth = new System.Windows.Forms.Label();
            this.tbMaxWidth = new System.Windows.Forms.TextBox();
            this.tbMaxHeight = new System.Windows.Forms.TextBox();
            this.lbMaxHeight = new System.Windows.Forms.Label();
            this.lbDirectory = new System.Windows.Forms.Label();
            this.tbDirectory = new System.Windows.Forms.TextBox();
            this.btnSelectDirectory = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 147);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Upraviť rozmery";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(12, 187);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(0, 13);
            this.label.TabIndex = 1;
            // 
            // lbMaxWidth
            // 
            this.lbMaxWidth.AutoSize = true;
            this.lbMaxWidth.Location = new System.Drawing.Point(12, 21);
            this.lbMaxWidth.Name = "lbMaxWidth";
            this.lbMaxWidth.Size = new System.Drawing.Size(84, 13);
            this.lbMaxWidth.TabIndex = 2;
            this.lbMaxWidth.Text = "Maximálna šírka";
            // 
            // tbMaxWidth
            // 
            this.tbMaxWidth.Location = new System.Drawing.Point(100, 18);
            this.tbMaxWidth.Name = "tbMaxWidth";
            this.tbMaxWidth.Size = new System.Drawing.Size(100, 20);
            this.tbMaxWidth.TabIndex = 3;
            // 
            // tbMaxHeight
            // 
            this.tbMaxHeight.Location = new System.Drawing.Point(100, 44);
            this.tbMaxHeight.Name = "tbMaxHeight";
            this.tbMaxHeight.Size = new System.Drawing.Size(100, 20);
            this.tbMaxHeight.TabIndex = 5;
            // 
            // lbMaxHeight
            // 
            this.lbMaxHeight.AutoSize = true;
            this.lbMaxHeight.Location = new System.Drawing.Point(12, 47);
            this.lbMaxHeight.Name = "lbMaxHeight";
            this.lbMaxHeight.Size = new System.Drawing.Size(88, 13);
            this.lbMaxHeight.TabIndex = 4;
            this.lbMaxHeight.Text = "Maximálna výška";
            // 
            // lbDirectory
            // 
            this.lbDirectory.AutoSize = true;
            this.lbDirectory.Location = new System.Drawing.Point(12, 73);
            this.lbDirectory.Name = "lbDirectory";
            this.lbDirectory.Size = new System.Drawing.Size(43, 13);
            this.lbDirectory.TabIndex = 6;
            this.lbDirectory.Text = "Adresár";
            // 
            // tbDirectory
            // 
            this.tbDirectory.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbDirectory.Location = new System.Drawing.Point(100, 70);
            this.tbDirectory.Name = "tbDirectory";
            this.tbDirectory.Size = new System.Drawing.Size(301, 20);
            this.tbDirectory.TabIndex = 7;
            // 
            // btnSelectDirectory
            // 
            this.btnSelectDirectory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSelectDirectory.Location = new System.Drawing.Point(407, 69);
            this.btnSelectDirectory.Name = "btnSelectDirectory";
            this.btnSelectDirectory.Size = new System.Drawing.Size(36, 23);
            this.btnSelectDirectory.TabIndex = 8;
            this.btnSelectDirectory.Text = "...";
            this.btnSelectDirectory.UseVisualStyleBackColor = true;
            this.btnSelectDirectory.Click += new System.EventHandler(this.btnSelectDirectory_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(440, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Program vykoná úpravu JPG obrázkov v zadanom adresári a všetkých jeho podadresáro" +
    "ch.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 261);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSelectDirectory);
            this.Controls.Add(this.tbDirectory);
            this.Controls.Add(this.lbDirectory);
            this.Controls.Add(this.tbMaxHeight);
            this.Controls.Add(this.lbMaxHeight);
            this.Controls.Add(this.tbMaxWidth);
            this.Controls.Add(this.lbMaxWidth);
            this.Controls.Add(this.label);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Úprava rozmerov JPG obrázkov";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label lbMaxWidth;
        private System.Windows.Forms.TextBox tbMaxWidth;
        private System.Windows.Forms.TextBox tbMaxHeight;
        private System.Windows.Forms.Label lbMaxHeight;
        private System.Windows.Forms.Label lbDirectory;
        private System.Windows.Forms.TextBox tbDirectory;
        private System.Windows.Forms.Button btnSelectDirectory;
        private System.Windows.Forms.Label label1;
    }
}

